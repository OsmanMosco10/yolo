# DEploy To Heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Obysoftt/tg-uploader-v7.1/tree/main)
